<div class="container">
    <?= form_open_multipart('balita/tambah');?>
        <legend>Ubah Data Balita</legend>
        <div class="mb-3">
            <label for="nama" class="form-label">nama</label>
            <input type="text" class="form-control" id="nama" name="nama" style="width : 500px;" value="<?= $balita['nama']; ?>">
            <div class="form-text text-danger"><?= form_error('nama'); ?></div>
        </div>
        <div class="mb-3">
            <label for=" tgl_lahir" class="form-label"> tgl lahir</label>
            <input type="date" class="form-control" id=" tgl_lahir" name=" tgl_lahir" style="width : 500px;" value="<?= $balita[' tgl_lahir']; ?>">
            <div class="form-text text-danger"><?= form_error(' tgl_lahir'); ?></div>
        </div> 
        <div class="mb-3">
             <label for="jenis_kelamin" class="form-label">jenis kelamin</label>
            <input type="text" class="form-control" id="jenis_kelamin" name="jenis_kelamin" style="width : 500px;" value="<?= $balita['jenis_kelamin']; ?>">
            <div class="form-text text-danger"><?= form_error('jenis_kelamin'); ?></div>
        </div>
        <div class="mb-3">
            <label for="umur" class="form-label">umur</label>
            <input type="text" class="form-control" id="umur" name="umur" style="width : 500px;" value="<?= $balita['umur']; ?>">
            <div class="form-text text-danger"><?= form_error('umur'); ?></div>
        </div> 
        <div class="mb-3">
            <label for="nama_ibu" class="form-label">nama ibu</label>
            <input type="text" class="form-control" id="nama_ibu" name="nama_ibu" style="width : 500px;" value="<?= $balita['nama_ibu']; ?>">
            <div class="form-text text-danger"><?= form_error('nama_ibu'); ?></div>
        </div> 
        <div class="mb-3">
            <label for="nama_ayah" class="form-label">nama ayah</label>
            <input type="text" class="form-control" id="nama_ayah" name="nama_ayah" style="width : 500px;" value="<?= $balita['nama_ayah']; ?>">
            <div class="form-text text-danger"><?= form_error('nama_ayah'); ?></div>
        </div> 
        <div class="mb-3">
            <label for="alamat" class="form-label">alamat</label>
            <input type="text" class="form-control" id="alamat" name="alamat" style="width : 500px;" value="<?= $balita['alamat']; ?>">
            <div class="form-text text-danger"><?= form_error('alamat'); ?></div>
        </div> 
        </div>
        <input type="submit" value="submit" class="btn btn-primary"></input>
    </form>
</div>








































